<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DEMORA</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <div class="container">
        <div class="sidebar">
            <?php include 'menu.php'; ?>
        </div>
        <div class="main-content">
            <div class="product-grid">
                <?php include 'xltksp.php'; ?>
            </div>
            <?php // Phân trang
            include 'ketnoi.php';
            $sql_count = "SELECT COUNT(*) AS total FROM Sanpham $whereQuery";
            $result_count = $conn->query($sql_count);

            if ($result_count === false) {
                die("Error executing count query: " . $conn->error);
            }

            $row_count = $result_count->fetch_assoc();
            $total_products = $row_count['total'];

            if ($total_products > 0) {
                $total_pages = ceil($total_products / $limit);
                echo "<div class='pagination'>";
                for ($i = 1; $i <= $total_pages; $i++) {
                    $url = "sanpham.php?page=$i";
                    if ($search) $url .= "&search=" . urlencode($search);
                    if ($gia) $url .= "&gia=$gia";
                    if ($maloai) $url .= "&maloai=$maloai";
                    echo "<li><a href='$url'>$i</a></li>";
                }
                echo "</div>";
            }
            $conn->close();
        ?>
        </div>
        
    </div>
    <?php include 'footer.php'; ?>
</body>
</html>
