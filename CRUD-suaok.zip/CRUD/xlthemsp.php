
<?php

    include 'ketnoi.php'; 
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $mahang=$_POST['mahang'];
        $tenhang = $_POST['tenhang'];
        $soluong = $_POST['soluong'];
        $mota = $_POST['mota'];
        $giahang = $_POST['giahang'];
        $maloai = $_POST['maloai']; // Sử dụng 'maloai'

        

        
        $hinhanh = $_FILES['hinhanh']['name'];
        $hinhanh_tmp = $_FILES['hinhanh']['tmp_name'];
        $target_dir = "images/";
        $target_file = $target_dir . basename($hinhanh);
        $errors = [];

        // Kiểm tra tên hàng không được trùng
        $sql_check_tenhang = "SELECT * FROM Sanpham WHERE Tenhang='$tenhang'";
        $result_check_tenhang = $conn->query($sql_check_tenhang);
        if ($result_check_tenhang->num_rows > 0) {
            $errors[] = "Tên hàng đã tồn tại.";
        }
        // Kiểm tra tên mã hàng không đưuọc trùng 
        $sql_check_mahang = "SELECT * FROM Sanpham WHERE Mahang='$mahang'";
        $result_check_tenhang = $conn->query($sql_check_mahang);
        if ($result_check_mahang->num_rows > 0) {
            $errors[] = "Tên hàng đã tồn tại.";
        }

        // Kiểm tra số lượng phải là int
        if (!filter_var($soluong, FILTER_VALIDATE_INT)) {
            $errors[] = "Số lượng phải là số nguyên.";
        }

        // Kiểm tra mã loại có tồn tại trong bảng Loaisp
        $sql_check_maloai = "SELECT * FROM Loaisp WHERE Maloai ='$maloai'";
        $result_check_maloai = $conn->query($sql_check_maloai);
        if ($result_check_maloai->num_rows == 0) {
            $errors[] = "Mã loại không tồn tại.";
        }

        // Kiểm tra định dạng hình ảnh
        $file_size = $_FILES['hinhanh']['size'];
        $file_extension = pathinfo($hinhanh, PATHINFO_EXTENSION);

        // Kiểm tra đuôi ảnh
        if (!in_array(strtolower($file_extension), ['jpg', 'jpeg'])) {
            $errors[] = "Đuôi ảnh phải là JPG hoặc JPEG.";
        }

        // Kiểm tra kích thước hình ảnh
        if ($file_size > 2 * 1024 * 1024) { // 2MB
            $errors[] = "Kích thước ảnh không được vượt quá 2MB.";
        }

        // Nếu không có lỗi, thực hiện thêm sản phẩm
        if (empty($errors)) {
            if (move_uploaded_file($hinhanh_tmp, $target_file)) {
                // Nếu upload hình ảnh thành công, thêm sản phẩm vào CSDL
                $sql = "INSERT INTO Sanpham (Mahang, Tenhang, Soluong, Hinhanh, Mota, Giahang, Maloai) 
                        VALUES ('$mahang', '$tenhang', '$soluong', '$hinhanh', '$mota', '$giahang', '$maloai')";

                if ($conn->query($sql) === TRUE) {
                    echo "<script>alert('Thêm sản phẩm thành công!'); window.location.href='sanpham.php';</script>";
                } else {
                    echo "<script>alert('Lỗi: " . $conn->error . "');</script>";
                }
            } else {
                echo "<script>alert('Lỗi khi tải hình ảnh lên.');</script>";
            }
        } else {
            // Hiển thị thông báo lỗi
            foreach ($errors as $error) {
                echo "<script>alert('$error');</script>";
            }
            echo "<script>window.history.back();</script>"; // Quay lại trang thêm sản phẩm
        }
    }

    $conn->close();
?>
