<header>
    <div class="container1">
        <div class="logo">
            <img src="images/logo.png" alt="Logo" />
        </div>
        <h1>DEMORA</h1>
        <div class="search-container">
            <form method="GET" action="xltksp.php">
                <input 
                    type="text" 
                    name="search" 
                    placeholder="Nhập từ khóa cần tìm kiếm..." 
                    class="search-input" 
                    value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>"
                />
                <button type="submit" class="search-button">Tìm kiếm</button>
            </form>
        </div>
    </div>
</header>