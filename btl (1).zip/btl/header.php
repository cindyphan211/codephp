<header>
    <div class="container1">
        <div class="logo">
            <img src="images/logo.png" alt="Logo" />
        </div>
        <h1>DEMORA-Luxury Accessories</h1>
        
        <!-- Phần Tìm kiếm -->
        <div class="search-container">
            <form method="GET" action="sanpham.php"> <!-- Đảm bảo action trỏ đến sanpham.php -->
                <input 
                    type="text" 
                    name="search" 
                    placeholder="Nhập từ khóa cần tìm kiếm..." 
                    class="search-input" 
                    value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>"
                    onkeyup="if(event.keyCode === 13) this.form.submit()"  <!-- Tự động submit khi nhấn Enter -->
                <button type="submit" class="search-button">Tìm kiếm</button>
            </form>
        </div>
    </div>
</header>
