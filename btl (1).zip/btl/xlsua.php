<?php
// Lấy thông tin cần sửa
$Mahang = $_POST['Mahang'];  
$Tenhang = $_POST['Tenhang']; 
$Mota = $_POST['Mota']; 
$soluong = $_POST['Soluong'];  
$giahang = $_POST['Giahang']; 
$maloai = $_POST['Maloai'];  
$hinhanh = $_FILES['hinhanh']['name']; 
$hinhanh_tmp = $_FILES['hinhanh']['tmp_name'];  i
$target_dir = "images/";  
$target_file = $target_dir . basename($hinhanh); 
$errors = [];  // Mảng lỗi

include 'ketnoi.php';  // Kết nối với cơ sở dữ liệu

// Kiểm tra tên hàng không được trùng (bỏ qua sản phẩm hiện tại)
$sql_select = "SELECT * FROM sanpham WHERE Tenhang='{$Tenhang}' AND Mahang != '{$Mahang}'";
$result = $conn->query($sql_select);
if ($result->num_rows > 0) {
    die("Đã có sản phẩm trùng tên");
}

// Kiểm tra số lượng phải là số nguyên
if (!filter_var($soluong, FILTER_VALIDATE_INT)) {
    $errors[] = "Số lượng phải là số nguyên.";
}
// Kiểm tra định dạng hình ảnh nếu có hình ảnh mới
if (!empty($hinhanh)) {
    $file_size = $_FILES['hinhanh']['size'];
    $file_extension = pathinfo($hinhanh, PATHINFO_EXTENSION);

    // Kiểm tra đuôi ảnh
    if (!in_array(strtolower($file_extension), ['jpg', 'jpeg'])) {
        $errors[] = "Đuôi ảnh phải là JPG hoặc JPEG.";
    }

    // Kiểm tra kích thước hình ảnh
    if ($file_size > 2 * 1024 * 1024) { // 2MB
        $errors[] = "Kích thước ảnh không được vượt quá 2MB.";
    }
}

// Nếu không có lỗi
if (empty($errors)) {
    // Nếu có hình ảnh mới, di chuyển nó vào thư mục
    if (!empty($hinhanh) && move_uploaded_file($hinhanh_tmp, $target_file)) {
        // Cập nhật sản phẩm với hình ảnh mới
        $sql = "UPDATE Sanpham SET Tenhang='$Tenhang', Mota='$Mota', Hinhanh='$hinhanh', Soluong='$soluong', Giahang='$giahang', Maloai='$maloai' WHERE Mahang='$Mahang'";
    } else {
        // Nếu không có hình ảnh mới, chỉ cập nhật các trường còn lại
        $sql = "UPDATE Sanpham SET Tenhang='$Tenhang', Mota='$Mota', Soluong='$soluong', Giahang='$giahang', Maloai='$maloai' WHERE Mahang='$Mahang'";
    }

    // Thực thi câu lệnh UPDATE
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Sửa sản phẩm thành công!'); window.location.href='sanpham.php';</script>";
    } else {
        echo "<script>alert('Lỗi: " . $conn->error . "');</script>";
    }
} else {
    // Hiển thị các lỗi nếu có
    foreach ($errors as $error) {
        echo "<script>alert('$error');</script>";
    }
    echo "<script>window.history.back();</script>"; 
}

$conn->close();
?>
