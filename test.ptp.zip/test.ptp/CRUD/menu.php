<div class="menu-container">
    <div class="menu">
        <h3>LOẠI SẢN PHẨM</h3>
            <ul>
                <?php
                    // Kết nối cơ sở dữ liệu
                    include 'ketnoi.php';
                    // Hiển thị danh mục loại sản phẩm
                    $sql_loaisp = "SELECT * FROM Loaisp";
                    $result_loaisp = $conn->query($sql_loaisp);

                    if ($result_loaisp->num_rows > 0) {
                        while($row = $result_loaisp->fetch_assoc()) {
                            echo "<li><a href='Sanpham.php?maloai=".$row['Maloai']."'>".$row['Tenloai']."</a></li>";
                        }
                    } else {
                        echo "<li>Không có loại sản phẩm nào.</li>";
                    }
                ?>
            </ul>
                
        </div>
    </div>
    <div class="filters">
                <form method="GET" action="sanpham.php">
                    
                    <h3>LỌC THEO GIÁ</h3>
                    <input type="radio" name="gia" value="" id="gia0" <?= !isset($_GET['gia']) || empty($_GET['gia']) ? 'checked' : '' ?>>
                    <label for="gia0">Tất cả</label><br>
                    <input type="radio" name="gia" value="0-500000" id="gia1" <?= isset($_GET['gia']) && $_GET['gia'] == '0-500000' ? 'checked' : '' ?>>
                    <label for="gia1">0 - 500.000đ</label><br>
                    <input type="radio" name="gia" value="500000-1000000" id="gia2" <?= isset($_GET['gia']) && $_GET['gia'] == '500000-1000000' ? 'checked' : '' ?>>
                    <label for="gia2">500.000đ - 1.000.000đ</label><br>
                    <input type="radio" name="gia" value="1000000-2000000" id="gia3" <?= isset($_GET['gia']) && $_GET['gia'] == '1000000-2000000' ? 'checked' : '' ?>>
                    <label for="gia3">1.000.000đ - 2.000.000đ</label><br>
                    <input type="radio" name="gia" value="2000000" id="gia4" <?= isset($_GET['gia']) && $_GET['gia'] == '2000000' ? 'checked' : '' ?>>
                    <label for="gia4">2.000.000đ trở lên</label><br>
                    
                    <input type="submit" value="Lọc">
                </form>
            </div>