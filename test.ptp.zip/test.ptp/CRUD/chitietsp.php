<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Detail</title>
    <style>       
        .image {
            max-width: 300px; 
            margin-right: 20px; 
            border-radius: 10px;
            margin-left: 70px;
        }

        .details {
            flex: 1; 
            max-width: 70%;
        }

        .details h1 {
            font-size: 24px;
            margin: 10px 0;
            color:#333;
        }

        .details .price {
            font-size: 35px;
            color: #333;
            margin: 10px 0;
        }

        .description, .class, .tenloai, .soluong {
            margin: 8px 0;
            margin-right: 50px;
            color: #333;
        }
        .product-info .class,
        .product-info .tenloai,
        .product-info .soluong {
            font-weight: bold; 
            color: #000; 
        }
        .product-info {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
            font-size: 16px;
            color: #333;
        }
        .product-info div {
            margin-right: 150px;
            text-align: center;
        }
        .product-info div:first-child {
            text-align: left; 
        }

        .product-info div:last-child {
            text-align: right; 
        }
        .buttons {
            margin-left: 28px;
            margin-right:-20px;
        }

        .buttons button {
            margin-top: 10px;
            padding: 10px 20px;
            background-color: #4CAF50;
            width: 145px;            
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .buttons button a {
            color: white;
            text-decoration: none;
        }

        .buttons button:hover {
            background-color: #388e3c;
        }
        
        .buttons {
            text-align: center;
        }
        .buttons button:first-child {
            margin-right: 10px; /* Khoảng cách giữa nút Sửa và nút Xóa */
        }
        <?php
        include 'style.css';
        ?>

    </style>
</head>

<body>
<?php
include 'ketnoi.php';

if (isset($_GET["Mahang"])) {
    $Mahang = $_GET["Mahang"];
    
    $stmt = $conn->prepare("SELECT * FROM sanpham WHERE Mahang = ?");
    $stmt->bind_param("s", $Mahang);
    $stmt->execute();
    $result = $stmt->get_result();

    // Kiểm tra xem có sản phẩm nào không
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        echo "<div class='image-container'>";
        echo "<img src='images/" . $row['Hinhanh'] . "' alt='" . $row['Tenhang'] . "' class='image'>";
        echo "<div class='buttons'>";
        echo "<button><a href='suasp.php?Mahang={$row['Mahang']}' class='button-link'>Sửa</a></button>";
        echo "<button><a href='xlxoa.php?Mahang={$row['Mahang']}' onclick='return check();' class='button-link'>Xóa</a></button>";
        echo "</div>";
        echo "</div>";
        
        echo "<div class='details'>";
        echo "<h1>" . htmlspecialchars($row['Tenhang']) . "</h1>";
        $formattedprice = number_format($row['Giahang'], 0, ',', ',');
        echo "<div class='price'>$" . $formattedprice . "</div>";

        echo "<div class='product-info'>";
        echo "<div class='class'>Mã hàng: " . htmlspecialchars($row['Mahang']) . "</div>";
        echo "<div class='tenloai'>Mã loại: " . htmlspecialchars($row['Maloai']) . "</div>";
        echo "<div class='soluong'>Số lượng: " . htmlspecialchars($row['Soluong']) . "</div>";
        echo "</div>";

        echo "<div class='description'>" . htmlspecialchars($row['Mota']) . "</div>";
        echo "</div>";
    } else {
        echo "<p>Không tìm thấy sản phẩm với mã hàng này.</p>";
    }

    $stmt->close();
} else {
    echo "<p>Mahang không hợp lệ.</p>";
}

$conn->close();
?>
<script>
function check() {
    return confirm('Bạn chắc chắn muốn xóa sản phẩm này?');
}
</script>

</html>
