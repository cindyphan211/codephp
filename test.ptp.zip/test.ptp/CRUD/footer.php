<footer>
        <div class="logo">
            <img src="images/logo.png" alt="Logo" /> 
        </div>
        
        <p>&copy; Nhóm 7 CRUD</p>
        
    </footer>