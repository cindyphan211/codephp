<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DEMORA</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <div class="actions">
    <a href="themsp.php" class="btn-action" title="Thêm sản phẩm mới">
        <i class="fas fa-plus"></i> Mới
    </a>
    <a href="import.php" class="btn-action" title="Import">
        <i class="fas fa-upload"></i> Import
    </a>
    <a href="export.php" class="btn-action" title="Export">
        <i class="fas fa-download"></i> Export
    </a>
</div>
    <div class="container">
        <div class="sidebar">
            <?php include 'menu.php'; ?>
        </div>
        <div class="main-content">
            <div class="product-grid">
                <?php 
                    // Thiết lập kết nối cơ sở dữ liệu
                    include 'ketnoi.php';

                    // Lấy các tham số từ URL
                    $maloai = isset($_GET['maloai']) ? $_GET['maloai'] : '';  // Lấy mã loại sản phẩm từ URL
                    $search = isset($_GET['search']) ? $_GET['search'] : '';    // Từ khóa tìm kiếm
                    $gia = isset($_GET['gia']) ? $_GET['gia'] : '';              // Lọc theo giá

                    // Thiết lập phân trang
                    $limit = 6;
                    $page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
                    $start = ($page - 1) * $limit;

                    // Tạo điều kiện lọc theo từ khóa tìm kiếm, giá và loại sản phẩm
                    $whereClause = [];

                    if (!empty($search)) {
                        $searchEscaped = $conn->real_escape_string($search);
                        $whereClause[] = "(Tenhang LIKE '%$searchEscaped%' OR Mota LIKE '%$searchEscaped%')";
                    }

                    if (!empty($gia)) {
                        if ($gia == '0-500000') {
                            $whereClause[] = "Giahang BETWEEN 0 AND 500000";
                        } elseif ($gia == '500000-1000000') {
                            $whereClause[] = "Giahang BETWEEN 500000 AND 1000000";
                        } elseif ($gia == '1000000-2000000') {
                            $whereClause[] = "Giahang BETWEEN 1000000 AND 2000000";
                        } elseif ($gia == '2000000') {
                            $whereClause[] = "Giahang >= 2000000";
                        }
                    }

                    if (!empty($maloai)) {
                        $whereClause[] = "Maloai = '$maloai'";
                    }

                    // Xây dựng câu truy vấn
                    $whereQuery = !empty($whereClause) ? "WHERE " . implode(' AND ', $whereClause) : '';

                    // Lấy sản phẩm theo điều kiện lọc và phân trang
                    $sql_sanpham = "SELECT * FROM Sanpham $whereQuery LIMIT $start, $limit";
                    $result_sanpham = $conn->query($sql_sanpham);

                    if ($result_sanpham === false) {
                        die("Error executing query: " . $conn->error);
                    }

                    // Hiển thị sản phẩm
                    if ($result_sanpham->num_rows > 0) {
                        while ($row = $result_sanpham->fetch_assoc()) {
                            $chitietsp_url = "chitietsp.php?Mahang=" . $row['Mahang'];
                            echo "<div class='product-item'>";
                            echo "<div class='image-container'>";
                            echo "<a href='$chitietsp_url'>";
                            echo "<img src='images/" . $row['Hinhanh'] . "' alt='" . $row['Tenhang'] . "'>";
                            echo "</a>";
                            echo "</div>";
                            echo "<h3><a href='$chitietsp_url'>" . $row['Tenhang'] . "</a></h3>";
                            echo "<p>" . number_format($row['Giahang']) . " đ</p>";
                            echo "</div>";
                        }
                    } else {
                        echo "<p>Không có sản phẩm nào phù hợp.</p>";
                    }

                    // Đếm tổng số sản phẩm để phân trang
                    $sql_count = "SELECT COUNT(*) AS total FROM Sanpham $whereQuery";
                    $result_count = $conn->query($sql_count);

                    if ($result_count === false) {
                        die("Error executing count query: " . $conn->error);
                    }

                    $row_count = $result_count->fetch_assoc();
                    $total_products = $row_count['total'];

                    // Hiển thị phân trang
                    if ($total_products > 0) {
                        $total_pages = ceil($total_products / $limit);
                        echo "<div class='pagination'>";
                        for ($i = 1; $i <= $total_pages; $i++) {
                            $url = "sanpham.php?page=$i";
                            if ($search) $url .= "&search=" . urlencode($search);
                            if ($gia) $url .= "&gia=$gia";
                            if ($maloai) $url .= "&maloai=$maloai";
                            echo "<li><a href='$url'>$i</a></li>";
                        }
                        echo "</div>";
                    }

                    $conn->close();
                ?>
            </div>
        </div>
    </div>
    <?php include 'footer.php'; ?>
</body>
</html>
