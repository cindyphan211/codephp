// Hiển thị hoặc ẩn menu dropdown khi nhấn vào icon bánh răng
document.querySelector('.btn-feature').addEventListener('click', function (e) {
    e.preventDefault();  // Ngừng hành động mặc định của nút
    const dropdown = this.parentElement; // Lấy thẻ cha của nút (div với class 'dropdown')
    dropdown.classList.toggle('show'); // Thêm hoặc bỏ class 'show' để hiển thị dropdown
});

// Ẩn menu dropdown khi click ra ngoài
document.addEventListener('click', function (e) {
    const dropdowns = document.querySelectorAll('.dropdown');
    dropdowns.forEach(dropdown => {
        if (!dropdown.contains(e.target)) {
            dropdown.classList.remove('show'); // Ẩn dropdown khi click ra ngoài
        }
    });
});
