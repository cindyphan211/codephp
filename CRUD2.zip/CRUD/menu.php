<div class="menu-container">
    <div class="menu">
        <h3>LOẠI SẢN PHẨM</h3>
            <ul>
                <?php
                    // Kết nối cơ sở dữ liệu
                    include 'ketnoi.php';
                    // Hiển thị danh mục loại sản phẩm
                    $sql_loaisp = "SELECT * FROM Loaisp";
                    $result_loaisp = $conn->query($sql_loaisp);

                    if ($result_loaisp->num_rows > 0) {
                        while($row = $result_loaisp->fetch_assoc()) {
                            echo "<li><a href='Sanpham.php?maloai=".$row['Maloai']."'>".$row['Tenloai']."</a></li>";
                        }
                    } else {
                        echo "<li>Không có loại sản phẩm nào.</li>";
                    }
                ?>
            </ul>
                
        </div>
    </div>