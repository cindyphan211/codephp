<?php
include 'ketnoi.php';

if ($conn === false) {
    die("Error: Could not connect. " . mysqli_connect_error());
}

// Lấy giá trị tìm kiếm và lọc giá
$search = isset($_GET['search']) ? trim($_GET['search']) : '';  // Từ khóa tìm kiếm
$gia = isset($_GET['gia']) ? $_GET['gia'] : '';  // Lọc theo giá

// Tạo điều kiện lọc theo từ khóa tìm kiếm và giá
$whereClause = [];

if (!empty($search)) {
    // Tìm kiếm theo từ khóa
    $searchEscaped = $conn->real_escape_string($search);
    $whereClause[] = "(Tenhang LIKE '%$searchEscaped%' OR Mota LIKE '%$searchEscaped%')";
}

if (!empty($gia)) {
    // Lọc theo khoảng giá
    if ($gia == '0-500000') {
        $whereClause[] = "Giahang BETWEEN 0 AND 500000";
    } elseif ($gia == '500000-1000000') {
        $whereClause[] = "Giahang BETWEEN 500000 AND 1000000";
    } elseif ($gia == '1000000-2000000') {
        $whereClause[] = "Giahang BETWEEN 1000000 AND 2000000";
    } elseif ($gia == '2000000') {
        $whereClause[] = "Giahang >= 2000000";
    }
}

// Xây dựng câu lệnh WHERE
$whereQuery = !empty($whereClause) ? "WHERE " . implode(' AND ', $whereClause) : '';

// Số sản phẩm mỗi trang
$limit = 10;

// Lấy trang hiện tại từ URL, mặc định là trang 1
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

// Truy vấn sản phẩm dựa trên từ khóa và giá trị lọc, với phân trang
$sql_sanpham = "SELECT * FROM sanpham $whereQuery LIMIT $start, $limit";
$result_sanpham = $conn->query($sql_sanpham);

if ($result_sanpham === false) {
    die("Error executing query: " . $conn->error);
}

// Đếm tổng số kết quả
$total_results_sql = "SELECT COUNT(*) AS total FROM sanpham $whereQuery";
$total_results_res = $conn->query($total_results_sql);
$total_results_row = $total_results_res->fetch_assoc();
$total_results = $total_results_row['total'];

// Thông báo số kết quả tìm được
if ($total_results > 0) {
    // Thông báo kèm từ khóa tìm kiếm nếu có
    $searchText = !empty($search) ? " với từ khóa <strong>" . htmlspecialchars($search) . "</strong>" : "";
    echo "<p>Có <strong>$total_results</strong> kết quả phù hợp$searchText.</p>";
} else {
    echo "<p>Không có sản phẩm nào phù hợp.</p>";
}

// Hiển thị sản phẩm
if ($result_sanpham->num_rows > 0) {
    while ($row = $result_sanpham->fetch_assoc()) {
        $chitietsp_url = "chitietsp.php?Mahang=" . $row['Mahang'];
        echo "<div class='product-item'>";
        echo "<div class='image-container'>";
        echo "<a href='$chitietsp_url'>";
        echo "<img src='images/" . $row['Hinhanh'] . "' alt='" . $row['Tenhang'] . "'>";
        echo "</a>";
        echo "</div>";
        echo "<h3><a href='$chitietsp_url'>" . $row['Tenhang'] . "</a></h3>";
        echo "<p>" . number_format($row['Giahang']) . " đ</p>";
        echo "</div>";
    }
} else {
    echo "<p>Không có sản phẩm nào phù hợp.</p>";
}

// Hiển thị phân trang
$total_pages = ceil($total_results / $limit);  // Tính tổng số trang

echo "<div class='pagination'>";
if ($page > 1) {
    echo "<a href='sanpham.php?page=" . ($page - 1) . "&search=" . urlencode($search) . "&gia=" . urlencode($gia) . "'>&laquo; Trước</a>";
}

for ($i = 1; $i <= $total_pages; $i++) {
    echo "<a href='sanpham.php?page=$i&search=" . urlencode($search) . "&gia=" . urlencode($gia) . "'>$i</a>";
}

if ($page < $total_pages) {
    echo "<a href='sanpham.php?page=" . ($page + 1) . "&search=" . urlencode($search) . "&gia=" . urlencode($gia) . "'>Sau &raquo;</a>";
}
echo "</div>";

$conn->close();
?>
