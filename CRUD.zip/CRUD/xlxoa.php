<?php 
$Mahang = $_GET["Mahang"];
include("ketnoi.php");


$stmt = $conn->prepare("DELETE FROM sanpham WHERE Mahang = ?");
$stmt->bind_param("s", $Mahang);


if ($stmt->execute()) {
    header("location:sanpham.php");
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>