<header>
        <div class="container1">
            <div class="logo">
                <img src="images/logo.png" alt="Logo" /> 
            </div>
            <h1>QUẢN LÝ KHO</h1>
            <div class="search-container">
                <input type="text" placeholder="Tìm kiếm..." class="search-input" />
                <button class="search-button">Tìm</button>
            </div>
            <div class="dropdown-container">
        <button class="dropdown-button">Chức năng</button>
        <div class="dropdown-menu">
            <a href="themsp.php">Thêm sản phẩm</a>
            <a href="import.php">Import</a>
            <a href="export.php">Export</a>
        </div>
    </div>
        </div>
</header>