<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Detail</title>
    <style>       
        .image {
            max-width: 300px; 
            margin-right: 20px; 
            border-radius: 10px;
            margin-left: 70px;
        }

        .details {
            flex: 1; 
            max-width: 70%;
        }

        .details h1 {
            font-size: 24px;
            margin: 10px 0;
            color:#333;
        }

        .details .price {
            font-size: 35px;
            color: #333;
            margin: 10px 0;
        }

        .description, .class, .tenloai, .soluong {
            margin: 5px 0;
            margin-right: 50px;
            color: #333;
        }
        .product-info .class,
        .product-info .tenloai,
        .product-info .soluong {
            font-weight: bold; 
            color: #000; 
        }
        .product-info {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
            font-size: 16px;
            color: #333;
        }
        .product-info div {
            margin-right: 180px;
            text-align: center;
        }
        .product-info div:first-child {
            text-align: left; 
        }

        .product-info div:last-child {
            text-align: right; 
        }
        <?php
        include 'style.css';
        ?>

    </style>
</head>

<body>
    <?php include 'header.php'; ?>
    <div class="container">
        <?php
            include 'ketnoi.php';
            $Mahang = $_GET["Mahang"];
            $sql = "SELECT * FROM sanpham WHERE Mahang = '$Mahang'";
            $result = $conn->query($sql);
            $row = $result->fetch_assoc();

            echo "<img src='images/".$row['Hinhanh']."' alt='".$row['Tenhang']."' class='image'>"; 
        ?>
        
        <div class="details">
            <?php
                echo "<h1>".$row['Tenhang']."</h1>";
                $formattedprice=number_format($row['Giahang'],0,',',',');
                echo "<div class='price'>$".$formattedprice."</div>";
            ?>
            
            <div class="product-info">
                <div class="class"><?php echo "Mã hàng: " . $row['Mahang']; ?></div>
                <div class="tenloai"><?php echo "Mã loại: " . $row['Maloai']; ?></div>
                <div class="soluong"><?php echo "Số lượng: " . $row['Soluong']; ?></div>
            </div>
            <div class="description">
                <?php
                    echo "<div class='description'>".$row['Mota']."</div>";
                    
                ?>
            </div>
        </div>
    </div>

    <?php
        $conn->close();
    ?>
    <?php include 'footer.php'; ?>
</body>

</html>
