<header>
    <div class="container1">
        <div class="logo">
            <img src="images/logo.png" alt="Logo" /> 
        </div>
        <h1>DEMORA</h1>
        <div class="search-container">
            <!-- Thêm form để gửi từ khóa tìm kiếm tới xltk.php -->
            <form action="xltk.php" method="GET">
                <input type="text" name="keyword" placeholder="Tìm kiếm..." class="search-input" />
                <button type="submit" class="search-button">Tìm</button>
            </form>
        </div>
        <div class="dropdown-container">
            <button class="dropdown-button">Chức năng</button>
            <div class="dropdown-menu">
                <a href="themsp.php">Thêm sản phẩm</a>
                <a href="import.php">Import</a>
                <a href="export.php">Export</a>
            </div>
        </div>
    </div>
</header>
