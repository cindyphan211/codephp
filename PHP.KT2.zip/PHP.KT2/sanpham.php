<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DEMORA</title>
    <style>
    <?php
    include 'style.css';
    ?>
    </style>
</head>
<body>
    <?php
    include 'header.php';

    // Khởi tạo biến $price_condition để tránh lỗi undefined
    $price_condition = '';

    // Kiểm tra nếu có giá trị lọc theo giá được gửi từ form
    if (isset($_GET['price']) && !empty($_GET['price'])) {
        $prices = $_GET['price'];
        $conditions = [];

        // Duyệt qua từng khoảng giá và thêm điều kiện vào mảng $conditions
        foreach ($prices as $price) {
            if ($price == "0-1000000") {
                $conditions[] = "(Giahang BETWEEN 0 AND 1000000)";
            } elseif ($price == "1000000-2000000") {
                $conditions[] = "(Giahang BETWEEN 1000000 AND 2000000)";
            } elseif ($price == "2000000+") {
                $conditions[] = "(Giahang >= 2000000)";
            }
        }

        // Ghép các điều kiện lại với nhau
        if (!empty($conditions)) {
            $price_condition = " AND (" . implode(" OR ", $conditions) . ")";
        }
    }
    ?>
    
    <div class="container">
        <!-- Loại sản phẩm -->
        <div class="menu-container">
            <?php include 'menu.php'; ?>
        </div>

        <!-- Nội dung sản phẩm -->
        <div class="content">
            <!-- Bảng sản phẩm -->
            <div class="product-list">
                <?php
                // Phân trang
                $limit = 6;
                $page = isset($_GET['page']) ? $_GET['page'] : 1;
                $start = ($page - 1) * $limit;

                // Truy vấn sản phẩm
                $sql_sanpham = "SELECT * FROM Sanpham WHERE 1=1 $price_condition LIMIT $start, $limit";
                $result_sanpham = $conn->query($sql_sanpham);

                if ($result_sanpham->num_rows > 0) {
                    while($row = $result_sanpham->fetch_assoc()) {
                        echo "<div class='product-item'>";
                        echo "<div class='image-container'>";
                        echo "<img src='images/".$row['Hinhanh']."' alt='".$row['Tenhang']."'>";
                        echo "<div class='tooltip'><a href='chitietsp.php?Mahang={$row['Mahang']}'>Xem chi tiết</a></div>";
                        echo "</div>";
                        echo "<h3>".$row['Tenhang']."</h3>";
                        echo "<p>" . number_format($row['Giahang']) . " đ</p>";
                        echo "</div>";
                    }
                } else {
                    echo "<p>Không có sản phẩm nào phù hợp với từ khóa.</p>";
                }
                ?>
            </div>

            <!-- Phân trang -->
            <div class="pagination">
                <?php
                    // Đếm tổng số sản phẩm để tính tổng số trang
                    $sql_count = "SELECT COUNT(Mahang) AS total FROM Sanpham WHERE 1=1 $price_condition";
                    $result_count = $conn->query($sql_count);
                    $row_count = $result_count->fetch_assoc();
                    $total_pages = ceil($row_count['total'] / $limit);

                    for ($i = 1; $i <= $total_pages; $i++) {
                        echo "<a href='Sanpham.php?page=$i" . (isset($_GET['price']) ? "&price=" . implode(',', $_GET['price']) : '') . "'>$i</a>";
                    }
                ?>
            </div>
        </div>

        <!-- Phần theo giá -->
        <div class="filter">
            <h3>Lọc theo giá</h3>
            <form method="GET">
                <div class="checkbox">
                    <input type="checkbox" name="price[]" value="0-1000000" id="price1" <?php echo (isset($_GET['price']) && in_array('0-1000000', $_GET['price'])) ? 'checked' : ''; ?>>
                    <label for="price1">0 - 1.000.000 đ</label>
                </div>
                <div class="checkbox">
                    <input type="checkbox" name="price[]" value="1000000-2000000" id="price2" <?php echo (isset($_GET['price']) && in_array('1000000-2000000', $_GET['price'])) ? 'checked' : ''; ?>>
                    <label for="price2">1.000.000 - 2.000.000 đ</label>
                </div>
                <div class="checkbox">
                    <input type="checkbox" name="price[]" value="2000000+" id="price3" <?php echo (isset($_GET['price']) && in_array('2000000+', $_GET['price'])) ? 'checked' : ''; ?>>
                    <label for="price3">2.000.000 đ trở lên</label>
                </div>
                <button type="submit">Lọc</button>
            </form>
        </div>
    </div>
    <?php include 'footer.php'; ?>
</body>
</html>
