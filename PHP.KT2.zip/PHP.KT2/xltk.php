<?php
// Kết nối tới CSDL
include 'ketnoi.php'; // Đảm bảo rằng tệp ketnoi.php đã chứa phần kết nối CSDL

// Lấy từ khóa tìm kiếm từ form
$keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '';

// Kiểm tra từ khóa có tồn tại hay không
if (!empty($keyword)) {
    // Truy vấn tìm kiếm sản phẩm theo tên có chứa từ khóa
    $sql_sanpham = "SELECT * FROM Sanpham WHERE Tenhang LIKE '%$keyword%'";
    $result_sanpham = $conn->query($sql_sanpham);

    // Kiểm tra nếu có kết quả trả về
    if ($result_sanpham === false) {
        die("Lỗi truy vấn: " . $conn->error);
    }

    // Đếm số lượng kết quả trả về
    $count = $result_sanpham->num_rows;
} else {
    // Nếu không có từ khóa tìm kiếm
    $count = 0;
}

 // Xử lý lọc sản phẩm theo loại và giá
 $maloai = isset($_GET['maloai']) ? $_GET['maloai'] : '';
 $price_filter = isset($_GET['price']) ? $_GET['price'] : [];
 $price_condition = '';

 // Lọc sản phẩm theo mức giá
 if (!empty($price_filter)) {
     $price_conditions = [];
     foreach ($price_filter as $price) {
         if ($price == '0-1000000') {
             $price_conditions[] = "Giahang BETWEEN 0 AND 1000000";
         } elseif ($price == '1000000-2000000') {
             $price_conditions[] = "Giahang BETWEEN 1000000 AND 2000000";
         } elseif ($price == '2000000+') {
             $price_conditions[] = "Giahang > 2000000";
         }
     }
     $price_condition = ' AND (' . implode(' OR ', $price_conditions) . ')';
 }
?>



<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kết quả tìm kiếm - DEMORA</title>
    <style>
    <?php
    include 'style.css';
    ?>
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    <div class="container">
        <?php include 'menu.php'; ?>       
        <div class="content">
            <?php if ($count == 0 && !empty($keyword)): ?>
                <div class="no-result">
                    <p class="message">Không có sản phẩm nào phù hợp với từ khóa: <span class="keyword"><?php echo htmlspecialchars($keyword); ?></span></p>
                    <p class="suggestion">Vui lòng nhập lại từ khóa tìm kiếm phù hợp hoặc thử xem các sản phẩm khác dưới đây.</p>
                    <a href="sanpham.php">Quay lại trang chủ</a>
                </div>
            <?php endif; ?>
        </div>
        <div class="clear"></div>
    </div>
    <?php include 'footer.php'; ?>
</body>
</html>
