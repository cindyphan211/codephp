

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sửa Sản Phẩm</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f7f6;
        }
        .container3{
            width: 50%;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            margin-top: 30px;
        }
        .container3 h1 {
            text-align: center;
            color: #4CAF50;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        label {
            font-weight: bold;
        }
        input[type="text"], input[type="number"], input[type="file"], select {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        input[type="submit"] {
            padding: 10px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        input[type="submit"]:hover {
            background-color: #388e3c;
        }
        .back-link {
            text-align: center;
            margin-top: 20px;
        }
        <?php
        include 'style.css';
        ?>
    </style>
</head>

<body>
    <?php include 'header.php'; ?>
   <?php
        //lấy thông tin của sp cần sửa
        $Mahang=$_GET["Mahang"];
        include("ketnoi.php");
        $sql="select * from sanpham where Mahang='$Mahang'";
        $result=$conn->query($sql);
        $row=$result->fetch_assoc();
        $conn->close();
    ?>
    <div class="container3">
        <h1>Sửa Sản Phẩm</h1>
        <form action="xlsua.php" method="POST" enctype="multipart/form-data">

            <label for="Mahang">Mã hàng:</label>
            <input type="text" name="Mahang" value="<?php echo $row['Mahang']; ?>" readonly><br>           
        
            <label for="Tenhang">Tên hàng:</label>
            <input type="text" name="Tenhang" value="<?php echo $row['Tenhang']; ?>"><br>

            <label for="Soluong">Số lượng:</label>
            <input type="number" name="Soluong" value="<?php echo $row['Soluong']; ?>"><br>

            <label for="Image">Hình ảnh:</label>
            <input type="file" name="Image" value="<?php echo $row['Hinhanh'];?>"><br>

            <label for="Mota">Mô tả:</label>
            <input type="text" name="Mota" value="<?php echo $row['Mota']; ?>"><br>
            <label for="maloai">Mã loại:</label>
            <select name="maloai" id="maloai" required>
                <option value="">Chọn loại hàng</option>
                <?php
                    
                    include 'ketnoi.php';                    
                    $sql_loaisp = "SELECT Maloai, Tenloai FROM Loaisp";
                    $result_loaisp = $conn->query($sql_loaisp);

                    if ($result_loaisp->num_rows > 0) {
                        while ($row = $result_loaisp->fetch_assoc()) {
                            echo "<option value='".$row['Maloai']."'>".$row['Tenloai']."</option>";
                        }
                    }
                ?>
            </select>

            <input type="submit" value="Sửa sp">
            <div class="back-link">
                <a href="sanpham.php">Quay lại trang sản phẩm</a>
            </div>
        </form>
    </div>
    
    <?php include 'footer.php'; ?>
</body>
</html>
