<!DOCTYPE html>
<html>
   <head>
      <!-- Basic -->
      <meta charset="utf-8" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <!-- Mobile Metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
      <!-- Site Metas -->
      <meta name="keywords" content="" />
      <meta name="description" content="" />
      <meta name="author" content="" />
      <link rel="shortcut icon" href="images/favicon.png" type="">
      <title></title>
      <!-- bootstrap core css -->
      <link rel="stylesheet" type="text/css" href="home/css/bootstrap.css" />
      <!-- font awesome style -->
      <link href="home/css/font-awesome.min.css" rel="stylesheet" />
      <!-- Custom styles for this template -->
      <link href="home/css/style.css" rel="stylesheet" />
      <!-- responsive style -->
      <link href="home/css/responsive.css" rel="stylesheet" />
      <style>
        /* Global styles */
            body {
            font-family: 'Roboto', sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
            color: #333;
            }

            h1, h2, h3, h4, h5, h6 {
            font-family: 'Georgia', serif;
            color: #222;
            }

            p {
            line-height: 1.6;
            font-size: 16px;
            margin-bottom: 20px;
            }         

            /* Blog section */
            .blog-section {
            background-color: #fff;
            padding: 40px 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin: 20px auto;
            }

            .blog-section h2 {
            text-align: center;
            font-size: 28px;
            color: #4caf50;
            margin-bottom: 20px;
            }

            .blog-section p {
            text-align: justify;
            margin-bottom: 15px;
            }
      </style>
   </head>
   <body>
      <div class="hero_area">
         <!-- header section strats -->
         @include('home.header')
         <!-- end header section -->
        
      
      <!-- Main content area -->
      <div class="container mt-5">
         <!-- Giới thiệu -->
         <h1 class="text-center mb-4">Chào mừng đến với BWKN</h1>
         <p class="text-center">
            Tại cửa hàng của chúng tôi, bạn sẽ tìm thấy những sản phẩm thời trang chất lượng cao, được chọn lọc kỹ lưỡng để mang lại trải nghiệm tốt nhất cho bạn.
         </p>

         <!-- Blog 1 -->
         <div class="blog-section mt-5">
            <h2 class="text-center">Về Chúng Tôi</h2>
            <p>
               Chào mừng bạn đến với BWKN, nơi mà chất lượng là yếu tố cốt lõi trong mọi sản phẩm của chúng tôi. Chúng tôi tự hào mang đến cho bạn những bộ quần áo được thiết kế không chỉ đẹp mắt mà còn bền bỉ qua thời gian. 
            </p>
            <p>
               Sản phẩm của chúng tôi được làm từ các loại vải cao cấp như cotton tự nhiên, lụa mềm mại và vải denim chắc chắn. Quy trình sản xuất luôn được kiểm soát chặt chẽ để đảm bảo mỗi đường may đều đạt tiêu chuẩn. Dù bạn đang tìm kiếm trang phục thường ngày, trang phục công sở hay những bộ đồ dự tiệc sang trọng, BWKN sẽ là sự lựa chọn hàng đầu.
            </p>
            <p>
               Ngoài việc mang đến sản phẩm chất lượng, chúng tôi còn chú trọng đến việc mang lại trải nghiệm mua sắm tuyệt vời. Hãy ghé thăm và khám phá sự khác biệt từ BWKN !
            </p>
         </div>

         
      </div>
     
      
      @include('home.footer')
      <!-- footer end -->
      <div class="cpy_">
         <p class="mx-auto">© 2021 All Rights Reserved By <a href="https://html.design/">Free Html Templates</a><br>
         
            Distributed By <a href="https://themewagon.com/" target="_blank">ThemeWagon</a>
         
         </p>
      </div>
      <!-- jQery -->
      <script src="home/js/jquery-3.4.1.min.js"></script>
      <!-- popper js -->
      <script src="home/js/popper.min.js"></script>
      <!-- bootstrap js -->
      <script src="home/js/bootstrap.js"></script>
      <!-- custom js -->
      <script src="home/js/custom.js"></script>
   </body>
</html>