<!DOCTYPE html>
<html>
   <head>
      <!-- Basic -->
      <meta charset="utf-8" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <!-- Mobile Metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
      <!-- Site Metas -->
      <meta name="keywords" content="" />
      <meta name="description" content="" />
      <meta name="author" content="" />
      <link rel="shortcut icon" href="images/favicon.png" type="">
      <title>Famms - Fashion HTML Template</title>
      <!-- bootstrap core css -->
      <link rel="stylesheet" type="text/css" href="home/css/bootstrap.css" />
      <!-- font awesome style -->
      <link href="home/css/font-awesome.min.css" rel="stylesheet" />
      <!-- Custom styles for this template -->
      <link href="home/css/style.css" rel="stylesheet" />
      <!-- responsive style -->
      <link href="home/css/responsive.css" rel="stylesheet" />
      <style>
        /* Căn chỉnh bảng giỏ hàng */
         .center {
         margin: 50px auto;
         text-align: center;
         width:90%;
         background-color: #f9f9f9;
         padding: 20px;
         border-radius: 10px;
         box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
         }

         /* Bảng sản phẩm */
         table {
         width: 100%;
         border-collapse: collapse;
         margin-top: 20px;
         }

         table, th, td {
         border: 1px solid #ddd;
         }

         th, td {
         padding: 15px;
         text-align: center;
         }

         .th_deg {
         font-size: 18px;
         background-color: #4caf50;
         color: white;
         text-transform: uppercase;
         }

         td {
         font-size: 16px;
         }

         .img_deg {
         width: 100px;
         height: auto;
         border-radius: 8px;
         }

         /* Nút */
         .btn {
         display: inline-block;
         padding: 10px 15px;
         font-size: 16px;
         border-radius: 5px;
         text-transform: uppercase;
         transition: all 0.3s ease;
         text-decoration: none;
         }

         .btn-danger {
         background-color: #e53935;
         color: white;
         border: none;
         }

         .btn-danger:hover {
         background-color: #b71c1c;
         }

         .btn-success {
         background-color: #4caf50;
         color: white;
         border: none;
         margin: 10px;
         }

         .btn-success:hover {
         background-color: #388e3c;
         }

         /* Tổng tiền */
         .total{
            margin-right:-300px;
         }
         .total h1 {
         font-size: 20px;
         margin-top: 20px;
         font-weight:bold;
         }

         h1 span {
         color: #4caf50;
         }

         /* Phương thức thanh toán */
         .payment-container {
            display: flex;
            align-items: center;
         }

         .payment-container h1 {
            margin-right: 20px; /* Khoảng cách giữa h1 và các nút */
         }

         .payment-container .btn {
            margin-right: 10px; /* Khoảng cách giữa các nút */
         }
               


      </style>
   </head>
   <body>
      <div class="hero_area">
         <!-- header section strats -->
         @include('home.header')
         <!-- end header section -->
      
      <div class="center">
        <table>
            <tr>
                <th class="th_deg">Tên sản phẩm </th>
                <th class="th_deg">Số lượng</th>
                <th class="th_deg">Giá</th>
                <th class="th_deg">Hình ảnh</th>
                <th class="th_deg"></th>

            </tr>
            <?php $totalprice=0; ?>
            @foreach($cart as $cart)
            <tr>
                <td>{{$cart->product_title}}</td>
                <td>{{$cart->quantity}}</td>
                <td>{{$cart->price}}</td>
                <td><img class="img_deg" src="/product/{{$cart->image}}" alt=""></td>
                <td>
                    <a class="btn btn-danger"onclick="return confirm('Bạn có muốn xóa sản phẩm ra khỏi giỏ hàng?')"href="{{url('/remove_cart',$cart->id)}}">Xóa</a>
                </td>
            </tr>
            <?php $totalprice=$totalprice + $cart->price ?>
            @endforeach
            

        </table>
        <div class="total">
                <h1>Tổng tiền: {{$totalprice}}</h1>
         </div>
         <div class="payment-container">
        <h1>Phương Thức Thanh Toán:</h1>
            <a href="{{url('cash_order')}}" class="btn btn-success">Thanh toán khi nhận</a>
            <a href="" class="btn btn-success">Chuyển khoản </a></div>
      </div>
      

      <!-- footer start -->
      @include('home.footer')
      <!-- footer end -->
      <div class="cpy_">
         <p class="mx-auto">© 2021 All Rights Reserved By <a href="https://html.design/">Free Html Templates</a><br>
         
            Distributed By <a href="https://themewagon.com/" target="_blank">ThemeWagon</a>
         
         </p>
      </div>
      <!-- jQery -->
      <script src="home/js/jquery-3.4.1.min.js"></script>
      <!-- popper js -->
      <script src="home/js/popper.min.js"></script>
      <!-- bootstrap js -->
      <script src="home/js/bootstrap.js"></script>
      <!-- custom js -->
      <script src="home/js/custom.js"></script>
   </body>
</html>