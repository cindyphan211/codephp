<!DOCTYPE html>
<html>
   <head>
      <!-- Basic -->
      <meta charset="utf-8" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <!-- Mobile Metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
      <!-- Site Metas -->
      <meta name="keywords" content="" />
      <meta name="description" content="" />
      <meta name="author" content="" />
      <link rel="shortcut icon" href="images/favicon.png" type="">
      <title>Famms - Fashion HTML Template</title>
      <!-- bootstrap core css -->
      <link rel="stylesheet" type="text/css" href="home/css/bootstrap.css" />
      <!-- font awesome style -->
      <link href="home/css/font-awesome.min.css" rel="stylesheet" />
      <!-- Custom styles for this template -->
      <link href="home/css/style.css" rel="stylesheet" />
      <!-- responsive style -->
      <link href="home/css/responsive.css" rel="stylesheet" />
      <style>
         .center {
            padding: 20px;
            overflow-x: auto;
         }

         table {
            width: 100%;
            border-collapse: collapse;
         }

         th, td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ddd;
         }

         th {
            background-color: #f4f4f4;
            font-weight: bold;
         }

         tr:nth-child(even) {
            background-color: #f9f9f9;
         }

         .btn-danger {
            background-color: #dc3545;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 5px;
         }

         .btn-danger:hover {
            background-color: #c82333;
         }

         .btn-danger:active {
            background-color: #bd2130;
         }

         .copy-text {
            text-align: center;
            margin-top: 20px;
         }

         .copy-text p {
            font-size: 14px;
            color: #777;
         }

         @media (max-width: 768px) {
            table {
               width: 100%;
               font-size: 14px;
            }

            th, td {
               padding: 8px;
            }

            .btn-danger {
               font-size: 14px;
               padding: 8px 12px;
            }
         }
      </style>
   </head>
   <body>
      <div class="hero_area">
         <!-- header section strats -->
         @include('home.header')
         <!-- end header section -->
         <div class="center">
            <table>
               <tr>
                     <th class="th_deg">Sản Phẩm</th>
                     <th class="th_deg">Số Lượng</th>
                     <th class="th_deg">Giá</th>
                     <th class="th_deg">PTTT</th>
                     <th class="th_deg">Trạng Thái Vận Chuyển</th>
                     <th></th>
                     
               </tr>
               @foreach($order as $order)
               <tr>
                     <td>{{ $order->product_title }}</td>
                     <td>{{ $order->quantity }}</td>
                     <td>{{ $order->price }}</td>
                     <td>{{ $order->payment_status }}</td>
                     <td>{{ $order->delivery_status }}</td>
                     <td>
                        @if($order->delivery_status=='processing')
                        <a onclick="return confirm('Bạn có chắc chắn muốn hủy đơn hàng này không?')" class="btn btn-danger"href="{{url('cancel_order',$order->id)}}">Hủy Đơn</a>
                        @else
                        <p></p>
                        @endif
                     </td>
                     
               </tr>
               @endforeach
            </table>
         </div>

      </div>
      
      
      
      <!-- footer start -->
      @include('home.footer')
      <!-- footer end -->
      <div class="cpy_">
         <p class="mx-auto">© 2021 All Rights Reserved By <a href="https://html.design/">Free Html Templates</a><br>
         
            Distributed By <a href="https://themewagon.com/" target="_blank">ThemeWagon</a>
         
         </p>
      </div>
      <!-- jQery -->
      <script src="home/js/jquery-3.4.1.min.js"></script>
      <!-- popper js -->
      <script src="home/js/popper.min.js"></script>
      <!-- bootstrap js -->
      <script src="home/js/bootstrap.js"></script>
      <!-- custom js -->
      <script src="home/js/custom.js"></script>
   </body>
</html>