<section class="subscribe_section">
         <div class="container-fuild">
            <div class="box">
               <div class="row">
                  <div class="col-md-6 offset-md-3">
                     <div class="subscribe_form ">
                        <div class="heading_container heading_center">
                           <h3>Đăng Kí Để Nhận Khuyến Mãi</h3>
                        </div>
                        <p>Cập nhập cũng mã khuyến mãi chỉ dành cho những người đăng kí.</p>
                        <form action="">
                           <input type="email" placeholder="Nhập địa chỉ email của bạn">
                           <button>
                           Đăng Kí
                           </button>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>