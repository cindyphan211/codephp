<!-- xlthemsp.php -->
<?php
// Kết nối cơ sở dữ liệu
include 'ketnoi.php'; // Include file kết nối CSDL

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Lấy dữ liệu từ form
    $tenhang = $_POST['tenhang'];
    $soluong = $_POST['soluong'];
    $mota = $_POST['mota'];
    $giahang = $_POST['giahang'];
    $maloai = $_POST['maloai']; // Sử dụng 'maloai'

    // Tạo mã hàng tự động
    $sql_max_mahang = "SELECT MAX(Mahang) AS max_mahang FROM Sanpham";
    $result_max_mahang = $conn->query($sql_max_mahang);
    $row_max_mahang = $result_max_mahang->fetch_assoc();
    $next_mahang = (int)substr($row_max_mahang['max_mahang'], 2) + 1; // Lấy phần số sau 'SP' và tăng lên 1
    $mahang = 'SP' . str_pad($next_mahang, 3, '0', STR_PAD_LEFT); // Định dạng mã hàng

    // Xử lý file hình ảnh
    $hinhanh = $_FILES['hinhanh']['name'];
    $hinhanh_tmp = $_FILES['hinhanh']['tmp_name'];

    // Di chuyển file hình ảnh vào thư mục 'images'
    $target_dir = "images/";
    $target_file = $target_dir . basename($hinhanh);

    // Mảng chứa thông báo lỗi
    $errors = [];

    // Kiểm tra tên hàng không được trùng
    $sql_check_tenhang = "SELECT * FROM Sanpham WHERE Tenhang='$tenhang'";
    $result_check_tenhang = $conn->query($sql_check_tenhang);
    if ($result_check_tenhang->num_rows > 0) {
        $errors[] = "Tên hàng đã tồn tại.";
    }

    // Kiểm tra số lượng phải là int
    if (!filter_var($soluong, FILTER_VALIDATE_INT)) {
        $errors[] = "Số lượng phải là số nguyên.";
    }

    // Kiểm tra giá hàng phải là decimal
    if (!preg_match("/^\d+(\.\d{1,2})?$/", $giahang)) {
        $errors[] = "Giá hàng phải ở dạng số thập phân.";
    }

    // Kiểm tra mã loại có tồn tại trong bảng Loaisp
    $sql_check_maloai = "SELECT * FROM Loaisp WHERE Maloai ='$maloai'";
    $result_check_maloai = $conn->query($sql_check_maloai);
    if ($result_check_maloai->num_rows == 0) {
        $errors[] = "Mã loại không tồn tại.";
    }

    // Kiểm tra định dạng hình ảnh
    $file_size = $_FILES['hinhanh']['size'];
    $file_extension = pathinfo($hinhanh, PATHINFO_EXTENSION);

    // Kiểm tra đuôi ảnh
    if (!in_array(strtolower($file_extension), ['jpg', 'jpeg'])) {
        $errors[] = "Đuôi ảnh phải là JPG hoặc JPEG.";
    }

    // Kiểm tra kích thước hình ảnh
    if ($file_size > 2 * 1024 * 1024) { // 2MB
        $errors[] = "Kích thước ảnh không được vượt quá 2MB.";
    }

    // Nếu không có lỗi, thực hiện thêm sản phẩm
    if (empty($errors)) {
        if (move_uploaded_file($hinhanh_tmp, $target_file)) {
            // Nếu upload hình ảnh thành công, thêm sản phẩm vào CSDL
            $sql = "INSERT INTO Sanpham (Mahang, Tenhang, Soluong, Hinhanh, Mota, Giahang, Maloai) 
                    VALUES ('$mahang', '$tenhang', '$soluong', '$hinhanh', '$mota', '$giahang', '$maloai')";

            if ($conn->query($sql) === TRUE) {
                echo "<script>alert('Thêm sản phẩm thành công!'); window.location.href='sanpham.php';</script>";
            } else {
                echo "<script>alert('Lỗi: " . $conn->error . "');</script>";
            }
        } else {
            echo "<script>alert('Lỗi khi tải hình ảnh lên.');</script>";
        }
    } else {
        // Hiển thị thông báo lỗi
        foreach ($errors as $error) {
            echo "<script>alert('$error');</script>";
        }
        echo "<script>window.history.back();</script>"; // Quay lại trang thêm sản phẩm
    }
}

$conn->close();
?>
