-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th10 07, 2024 lúc 03:04 PM
-- Phiên bản máy phục vụ: 10.4.32-MariaDB
-- Phiên bản PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `qlsanpham`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `loaisp`
--

CREATE TABLE `loaisp` (
  `Maloai` varchar(5) NOT NULL,
  `Tenloai` varchar(50) NOT NULL,
  `Mota` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Đang đổ dữ liệu cho bảng `loaisp`
--

INSERT INTO `loaisp` (`Maloai`, `Tenloai`, `Mota`) VALUES
('L001', 'Kem đánh răng ngừa sâu răng', 'Chứa fluoride giúp ngăn ngừa sâu răng'),
('L002', 'Kem đánh răng trắng răng', 'Làm trắng răng và loại bỏ vết ố'),
('L003', 'Kem đánh răng chống ê buốt', 'Giúp giảm ê buốt răng'),
('L004', 'Kem đánh răng thảo dược', 'Sử dụng thành phần tự nhiên để làm sạch răng'),
('L005', 'Kem đánh răng trẻ em', 'Kem đánh răng dành riêng cho trẻ em với hàm lượng fluoride thấp'),
('L006', 'Kem đánh răng than hoạt tính', 'Chứa than hoạt tính giúp làm trắng răng'),
('L007', 'Kem đánh răng ngừa viêm lợi', 'Giúp giảm viêm lợi'),
('L008', 'Kem đánh răng trị mảng bám', 'Ngăn ngừa sự hình thành mảng bám trên răng'),
('L009', 'Kem đánh răng dành cho răng nhạy cảm', 'Bảo vệ răng nhạy cảm và giảm ê buốt'),
('L010', 'Kem đánh răng toàn diện', 'Chăm sóc toàn diện cho răng và nướu');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `sanpham`
--

CREATE TABLE `sanpham` (
  `Mahang` varchar(5) NOT NULL,
  `Tenhang` varchar(50) NOT NULL,
  `Soluong` int(11) NOT NULL,
  `Hinhanh` varchar(30) NOT NULL,
  `Mota` varchar(100) NOT NULL,
  `Giahang` decimal(10,1) NOT NULL,
  `Maloai` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Lưu tên file ảnh ';

--
-- Đang đổ dữ liệu cho bảng `sanpham`
--

INSERT INTO `sanpham` (`Mahang`, `Tenhang`, `Soluong`, `Hinhanh`, `Mota`, `Giahang`, `Maloai`) VALUES
('SP002', 'Kem đánh răng Thái Lan', 200, 'toothpaste_b.jpg', 'Whitening toothpaste', 30000.0, 'L001'),
('SP003', 'Kem đánh răng Sensodyne', 150, 'toothpaste_c.jpg', 'Với hương vị bạc hà thơm mát, Sensodyne giúp làm sạch và bảo vệ răng miệng', 28000.0, 'L001'),
('SP004', 'Kem đánh răng Listerine', 120, 'toothpaste_d.jpg', 'Cung cấp nhiều lợi ích như bảo vệ chống sâu răng, viêm nướu, và làm trắng răng. ', 35000.0, 'L001'),
('SP005', 'Kem đánh răng Close-Up', 180, 'toothpaste_e.jpg', 'Kem đánh răng toàn diện giúp ngăn ngừa sâu răng, làm trắng răng, và giảm viêm nướu', 27000.0, 'L002'),
('SP007', 'Kem đánh răng Colgate Optic White', 160, 'toothpaste_g.jpg', 'Kem đánh răng này chứa công thức đặc biệt giúp làm trắng răng', 32000.0, 'L002'),
('SP008', 'Kem đánh răng Fluocaril', 190, 'toothpaste_h.jpg', 'Chứa fluoride, kem đánh răng này giúp ngăn ngừa sâu răng', 30000.0, 'L002'),
('SP009', 'Kem đánh răng Auromere', 130, 'toothpaste_i.jpg', 'Kem đánh răng ayurvedic với thành phần tự nhiên, giúp làm sạch và bảo vệ răng miệng một cách nhẹ nhà', 25000.0, 'L003'),
('SP010', 'Kem đánh răng Close-Up 2  trong 1', 170, 'toothpaste_j.jpg', 'Kem đánh răng này giúp làm sạch sâu, bảo vệ nướu.', 31000.0, 'L003'),
('SP011', 'Kem đánh răng Crest Pro-Health', 155, 'toothpaste_k.jpg', 'Cung cấp nhiều lợi ích như bảo vệ chống sâu răng', 29500.0, 'L003'),
('SP012', 'Kem đánh răng Listerine', 135, 'toothpaste_l.jpg', 'Giúp kiểm soát vi khuẩn gây hôi miệng.', 34000.0, 'L004'),
('SP013', 'Kem đánh răng Crest 3D White', 145, 'toothpaste_m.jpg', 'Sản phẩm này giúp loại bỏ các vết bẩn và mang lại nụ cười rạng rỡ.', 36000.0, 'L004'),
('SP014', 'Kem đánh răng Auromere', 125, 'toothpaste_n.jpg', 'Kem đánh răng giúp làm sạch và bảo vệ răng miệng một cách nhẹ nhàng.', 28000.0, 'L004'),
('SP015', 'Kem đánh răng Marvis', 115, 'toothpaste_o.jpg', 'Marvis không chỉ làm sạch mà còn mang lại trải nghiệm thưởng thức khác biệt.', 29000.0, 'L005'),
('SP016', 'Toothpaste P', 122, 'toothpaste_p.jpg', 'hàng tốt', 35000.0, 'L005'),
('SP017', 'Kem đánh răng Charcoal', 120, 'toothpaste_c.jpg', 'Sản phẩm chứa than hoạt tính giúp làm trắng và làm sạch răng', 85000.0, 'L001'),
('SP018', 'Toothpaste HH', 120, 'kemdanhrangnhat.jpg', 'Kem đánh răng Nhật Bản', 120000.0, 'L001'),
('SP019', 'Toothpaste MH', 110, 'colagate.jpg', 'Kem đánh răng Colgate', 11000.0, 'L005'),
('SP020', 'Kem đánh răng Việt Nam', 50, 'third runner up.jpg', 'Kem đánh răng Colgate', 30000.0, 'L005');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `loaisp`
--
ALTER TABLE `loaisp`
  ADD UNIQUE KEY `Maloai` (`Maloai`);

--
-- Chỉ mục cho bảng `sanpham`
--
ALTER TABLE `sanpham`
  ADD PRIMARY KEY (`Mahang`),
  ADD KEY `fk_maloai` (`Maloai`);

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `sanpham`
--
ALTER TABLE `sanpham`
  ADD CONSTRAINT `fk_maloai` FOREIGN KEY (`Maloai`) REFERENCES `loaisp` (`Maloai`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
