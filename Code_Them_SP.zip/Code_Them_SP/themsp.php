<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm Sản Phẩm</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f7f6;
        }
        .container {
            width: 50%;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            margin-top: 30px;
        }
        h1 {
            text-align: center;
            color: #4CAF50;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        label {
            font-weight: bold;
        }
        input[type="text"], input[type="number"], input[type="file"], select {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        input[type="submit"] {
            padding: 10px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        input[type="submit"]:hover {
            background-color: #388e3c;
        }
        .back-link {
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>THÊM SẢN PHẨM</h1>
        <form action="xlthemsp.php" method="POST" enctype="multipart/form-data">

            <label for="tenhang">Tên hàng:</label>
            <input type="text" name="tenhang" id="tenhang" required>
            <small style="font-style: italic;">Ví dụ: Kem đánh răng PS</small> <!-- Ví dụ hợp lệ cho tên hàng -->

            <label for="soluong">Số lượng:</label>
            <input type="number" name="soluong" id="soluong" required>
            <small style="font-style: italic;">Ví dụ hợp lệ: 50</small> <!-- Ví dụ hợp lệ cho số lượng -->

            <label for="hinhanh">Hình ảnh:</label>
            <input type="file" name="hinhanh" id="hinhanh" required>
            <small style="font-style: italic;">Kích thước ảnh không được vượt quá 2MB</small> <!-- Ví dụ hợp lệ cho hình ảnh -->

            <label for="mota">Mô tả:</label>
            <input type="text" name="mota" id="mota" required>

            <label for="giahang">Giá hàng:</label>
            <input type="number" step="0.01" name="giahang" id="giahang" required>
            <small style="font-style: italic;">Ví dụ hợp lệ: 20000</small> <!-- Ví dụ hợp lệ cho giá hàng -->

            <label for="maloai">Mã loại:</label>
            <select name="maloai" id="maloai" required>
                <option value="">Chọn loại hàng</option>
                <?php
                // Kết nối cơ sở dữ liệu từ file ketnoi.php
                include 'ketnoi.php'; // Include file kết nối CSDL

                // Truy vấn để lấy loại sản phẩm
                $sql_loaisp = "SELECT Maloai, Tenloai FROM Loaisp";
                $result_loaisp = $conn->query($sql_loaisp);

                if ($result_loaisp->num_rows > 0) {
                    while ($row = $result_loaisp->fetch_assoc()) {
                        echo "<option value='".$row['Maloai']."'>".$row['Tenloai']."</option>";
                    }
                }
                ?>
            </select>

            <input type="submit" value="Thêm sản phẩm">
        </form>
        <div class="back-link">
            <a href="sanpham.php">Quay lại trang sản phẩm</a>
        </div>
    </div>
</body>
</html>
