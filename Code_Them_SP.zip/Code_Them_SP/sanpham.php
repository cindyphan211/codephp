<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh Mục Sản Phẩm</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f7f6;
            color: #333;
            line-height: 1.6;
        }
        .container {
            width: 90%;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            border-radius: 10px;
            margin-top: 30px;
        }
        h1, h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #4CAF50;
        }
        .info {
            text-align: center;
            margin-bottom: 20px;
            padding: 5px 10px;
            border: 1px solid #333;
            border-radius: 5px;
            background-color: #F4F6FF;
            display: inline-block;
            font-size: 14px;
            color: #333;
        }
        .menu {
            width: 25%;
            float: left;
            padding: 20px;
            background-color: #4CAF50;
            border-radius: 10px;
        }
        .menu h3 {
            color: #fff;
            margin-bottom: 10px;
            font-size: 18px;
            text-align: center;
        }
        .menu ul {
            list-style-type: none;
            padding: 0;
        }
        .menu ul li {
            margin-bottom: 10px;
        }
        .menu ul li a {
            text-decoration: none;
            color: #fff;
            padding: 10px 15px;
            display: block;
            background-color: #66bb6a;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            text-align: center;
        }
        .menu ul li a:hover {
            background-color: #388e3c;
        }
        .content {
            width: 70%;
            float: right;
            padding: 20px;
        }
        .content h3 {
            font-size: 22px;
            margin-bottom: 20px;
            color: #4CAF50;
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 15px;
            text-align: center;
        }
        th {
            background-color: #4CAF50;
            color: #fff;
        }
        td img {
            max-width: 100px;
            border-radius: 5px;
        }
        .pagination {
            text-align: center;
            margin-top: 20px;
        }
        .pagination a {
            padding: 10px 20px;
            margin: 0 5px;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .pagination a:hover {
            background-color: #388e3c;
        }
        .clear {
            clear: both;
        }
        .detail-link {
            color: #4CAF50;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Thông tin bài kiểm tra -->
        <div class="info">
            <p>Bài kiểm tra: Lập trình web với PHP</p>
            <p>Họ và tên học viên: Phan Thị Phương Anh</p>
        </div>
        <h1>DANH MỤC SẢN PHẨM</h1>

        <!-- Danh mục sản phẩm -->
        <div class="menu">
            <h3>LOẠI SẢN PHẨM</h3>
            <ul>
                <?php
                // Kết nối cơ sở dữ liệu
                include 'ketnoi.php';

                // Hiển thị danh mục loại sản phẩm
                $sql_loaisp = "SELECT * FROM Loaisp";
                $result_loaisp = $conn->query($sql_loaisp);

                if ($result_loaisp->num_rows > 0) {
                    while($row = $result_loaisp->fetch_assoc()) {
                        echo "<li><a href='Sanpham.php?maloai=".$row['Maloai']."'>".$row['Tenloai']."</a></li>";
                    }
                } else {
                    echo "<li>Không có loại sản phẩm nào.</li>";
                }
                ?>
            </ul>
        </div>

        <!-- Nội dung sản phẩm -->
        <div class="content">
            <!-- Thêm sản phẩm -->
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h3 style="margin: 0; text-align: center; width: 100%;">DANH SÁCH SẢN PHẨM</h3>
                <a href="themsp.php" style="padding: 5px 10px; background-color: #79AC78; color: #fff; text-decoration: none; border-radius: 5px; font-size: 14px; white-space: nowrap;">Thêm sản phẩm</a>
            </div>

            <!-- Bảng sản phẩm -->
            <table>
                <tr>
                    <th>Mã hàng</th>
                    <th>Tên hàng</th>
                    <th>Hình ảnh</th>
                    <th>Chi tiết</th>
                </tr>
                <?php
                // Xử lý lọc sản phẩm theo loại
                $maloai = isset($_GET['maloai']) ? $_GET['maloai'] : '';

                // Phân trang
                $limit = 3;
                $page = isset($_GET['page']) ? $_GET['page'] : 1;
                $start = ($page - 1) * $limit;

                // Truy vấn sản phẩm
                if ($maloai != '') {
                    $sql_sanpham = "SELECT * FROM Sanpham WHERE Maloai='$maloai' LIMIT $start, $limit";
                } else {
                    $sql_sanpham = "SELECT * FROM Sanpham LIMIT $start, $limit";
                }

                $result_sanpham = $conn->query($sql_sanpham);

                if ($result_sanpham->num_rows > 0) {
                    while($row = $result_sanpham->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>".$row['Mahang']."</td>";
                        echo "<td>".$row['Tenhang']."</td>";
                        echo "<td><img src='images/".$row['Hinhanh']."' alt='".$row['Tenhang']."'></td>";
                        echo "<td><a href='chitietsp.php?mahang=".$row['Mahang']."' class='detail-link'>Xem chi tiết</a></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>Không có sản phẩm nào.</td></tr>";
                }
                ?>
            </table>

            <!-- Phân trang -->
            <div class="pagination">
                <?php
                // Đếm tổng số sản phẩm để tính tổng số trang
                $sql_count = "SELECT COUNT(Mahang) AS total FROM Sanpham";
                $result_count = $conn->query($sql_count);
                $row_count = $result_count->fetch_assoc();
                $total_pages = ceil($row_count['total'] / $limit);

                for ($i = 1; $i <= $total_pages; $i++) {
                    echo "<a href='Sanpham.php?page=$i".($maloai ? "&maloai=$maloai" : "")."'>$i</a>";
                }
                ?>
            </div>

        </div>

        <div class="clear"></div>
    </div>
</body>
</html>
